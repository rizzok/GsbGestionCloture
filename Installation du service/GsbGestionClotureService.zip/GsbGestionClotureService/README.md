# Instructions d'installation du service Windows

Après avoir décompréssé cette archive :  

- ouvrir un invite de commande en tant qu'administrateur  

- se placer avec l'invite dans de dossier contenant l'exécutable :  
```
cd cheminDuDossier
```

- lancer l'installation et le démarrage du service avec :  
```
GsbGestionClotureService.exe install start  
```

--------------------

- Pour désinstaller le service :  
```
GsbGestionClotureService.exe uninstall
```